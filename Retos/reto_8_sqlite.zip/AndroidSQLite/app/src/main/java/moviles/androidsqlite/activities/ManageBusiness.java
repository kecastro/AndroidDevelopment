package moviles.androidsqlite.activities;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import moviles.androidsqlite.R;
import moviles.androidsqlite.db.BusinessOperations;
import moviles.androidsqlite.entities.Business;
import moviles.androidsqlite.entities.Kind;

/**
 * Created by kcastrop on 13/11/17.
 */

public class ManageBusiness extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText name;
    private EditText url;
    private EditText phone;
    private EditText email;
    private EditText products;
    private Spinner kinds;
    private Button update;
    private Button delete;

    private Business business;
    private BusinessOperations businessData;

    String businessId;
    ArrayAdapter<Kind> adapter;
    int kindPosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_business);
        Bundle bundle = getIntent().getExtras();
        businessId = bundle.getString("businessId");

        business = new Business();

        name = (EditText)findViewById(R.id.name);
        url = (EditText)findViewById(R.id.url);
        phone = (EditText)findViewById(R.id.phone);
        email = (EditText)findViewById(R.id.email);
        products = (EditText)findViewById(R.id.products);
        kinds = (Spinner) findViewById(R.id.kinds);
        update = (Button)findViewById(R.id.btn_update);
        delete = (Button)findViewById(R.id.btn_delete);

        adapter = new ArrayAdapter<Kind>(this, android.R.layout.simple_spinner_item, Kind.values());
        kinds.setAdapter(adapter);
        kinds.setOnItemSelectedListener(this);

        businessData = new BusinessOperations(this);
        businessData.open();

        initializeBusiness(Long.parseLong(businessId));

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                business.setName(name.getText().toString());
                business.setUrl(url.getText().toString());
                business.setPhone(phone.getText().toString());
                business.setEmail(email.getText().toString());
                business.setProducts(products.getText().toString());
                businessData.updateBusiness(business);

                Intent i = new Intent(ManageBusiness.this,MainActivity.class);
                startActivity(i);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog confirmDelete = AskOption();
                confirmDelete.show();
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        business.setKind(Kind.valueOf(parent.getItemAtPosition(pos).toString()));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    private void initializeBusiness(long busId) {
        business = businessData.getBusiness(busId);
        name.setText(business.getName());
        url.setText(business.getUrl());
        phone.setText(business.getPhone());
        email.setText(business.getEmail());
        products.setText(business.getProducts());
        kindPosition = adapter.getPosition(business.getKind());
        kinds.setSelection(kindPosition);
    }

    private AlertDialog AskOption()
    {
        AlertDialog myQuittingDialogBox =new AlertDialog.Builder(this)
                //set message, title, and icon
                .setTitle("Borrar empresa")
                .setMessage("Seguro que quiere borrar")
                .setIcon(R.drawable.delete)

                .setPositiveButton("Borrar", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int whichButton) {
                        businessData.removeBusiness(businessData.getBusiness(Long.parseLong(businessId)));
                        Intent i = new Intent(ManageBusiness.this,MainActivity.class);
                        startActivity(i);
                        dialog.dismiss();
                    }

                })



                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();

                    }
                })
                .create();
        return myQuittingDialogBox;

    }

}


