package moviles.androidsqlite.activities;

import android.app.ListActivity;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

import moviles.androidsqlite.R;
import moviles.androidsqlite.db.BusinessOperations;
import moviles.androidsqlite.entities.Business;

public class MainActivity extends AppCompatActivity{

    private BusinessOperations businessOps;
    List<Business> businesses;

    private ListView businessesList;

    FloatingActionButton fabCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fabCreate = (FloatingActionButton) findViewById(R.id.fab_create);
        fabCreate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), AddBusiness.class);
                startActivity(intent);
            }
        });

        businessesList = (ListView) findViewById(R.id.list_business);

        businessOps = new BusinessOperations(this);
        businessOps.open();
        businesses = businessOps.getAllBusinesses();
        businessOps.close();
        ArrayAdapter<Business> adapter = new ArrayAdapter<Business>(MainActivity.this, android.R.layout.simple_list_item_1, businesses);
        businessesList.setAdapter(adapter);

        businessesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String id = Long.toString(businesses.get(i).getId());
                Intent intent = new Intent(getApplicationContext(),ManageBusiness.class);
                intent.putExtra("businessId", id);
                startActivity(intent);
            }
        });
    }

}
