package moviles.androidsqlite.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

import moviles.androidsqlite.entities.Business;
import moviles.androidsqlite.entities.Kind;

/**
 * Created by kcastrop on 12/11/17.
 */

public class BusinessOperations {
    
    public static final String LOGTAG = "BUSINESSES_SYS";

    SQLiteOpenHelper dbhandler;
    SQLiteDatabase database;

    private static final String[] allColumns = {
            BusinessDBHandler.COLUMN_ID,
            BusinessDBHandler.COLUMN_NAME,
            BusinessDBHandler.COLUMN_URL,
            BusinessDBHandler.COLUMN_PHONE,
            BusinessDBHandler.COLUMN_EMAIL,
            BusinessDBHandler.COLUMN_PRODUCTS,
            BusinessDBHandler.COLUMN_KIND

    };

    public BusinessOperations(Context context){
        dbhandler = new BusinessDBHandler(context);
    }

    public void open(){
        Log.i(LOGTAG,"Database Opened");
        database = dbhandler.getWritableDatabase();


    }

    public void close(){
        Log.i(LOGTAG, "Database Closed");
        dbhandler.close();

    }

    public Business addBusiness(Business Business){
        ContentValues values  = new ContentValues();
        values.put(BusinessDBHandler.COLUMN_NAME, Business.getName());
        values.put(BusinessDBHandler.COLUMN_URL, Business.getUrl());
        values.put(BusinessDBHandler.COLUMN_PHONE, Business.getPhone());
        values.put(BusinessDBHandler.COLUMN_EMAIL, Business.getEmail());
        values.put(BusinessDBHandler.COLUMN_PRODUCTS, Business.getProducts());
        values.put(BusinessDBHandler.COLUMN_KIND, String.valueOf(Business.getKind()));
        long insertid = database.insert(BusinessDBHandler.TABLE_BUSINESSES, null, values);
        Business.setId(insertid);
        return Business;

    }

    // Getting single Business
    public Business getBusiness(long id) {

        Cursor cursor = database.query(BusinessDBHandler.TABLE_BUSINESSES,allColumns,BusinessDBHandler.COLUMN_ID + "=?",new String[]{String.valueOf(id)},null,null, null, null);
        if (cursor != null)
            cursor.moveToFirst();

        Business b = new Business(Integer.parseInt(cursor.getString(0)),cursor.getString(1),cursor.getString(2),cursor.getString(3),cursor.getString(4),cursor.getString(5), Kind.valueOf(cursor.getString(6)));
        // return Business
        return b;
    }

    public List<Business> getAllBusinesses() {

        Cursor cursor = database.query(BusinessDBHandler.TABLE_BUSINESSES,allColumns,null,null,null, null, null);

        List<Business> businesses = new ArrayList<>();
        if(cursor.getCount() > 0){
            while(cursor.moveToNext()){
                Business business = new Business();
                business.setId(cursor.getLong(cursor.getColumnIndex(BusinessDBHandler.COLUMN_ID)));
                business.setName(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_NAME)));
                business.setUrl(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_URL)));
                business.setPhone(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_PHONE)));
                business.setEmail(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_EMAIL)));
                business.setProducts(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_PRODUCTS)));
                business.setKind(Kind.valueOf(cursor.getString(cursor.getColumnIndex(BusinessDBHandler.COLUMN_KIND))));
                businesses.add(business);
            }
        }
        // return All Businesses
        return businesses;
    }




    // Updating Business
    public int updateBusiness(Business business) {

        ContentValues values = new ContentValues();
        values.put(BusinessDBHandler.COLUMN_NAME, business.getName());
        values.put(BusinessDBHandler.COLUMN_URL, business.getUrl());
        values.put(BusinessDBHandler.COLUMN_PHONE, business.getPhone());
        values.put(BusinessDBHandler.COLUMN_EMAIL, business.getEmail());
        values.put(BusinessDBHandler.COLUMN_PRODUCTS, business.getProducts());
        values.put(BusinessDBHandler.COLUMN_KIND, business.getKind().name());

        // updating row
        return database.update(BusinessDBHandler.TABLE_BUSINESSES, values,
                BusinessDBHandler.COLUMN_ID + "=?",new String[] { String.valueOf(business.getId())});
    }

    // Deleting Business
    public void removeBusiness(Business business) {

        database.delete(BusinessDBHandler.TABLE_BUSINESSES, BusinessDBHandler.COLUMN_ID + "=" + business.getId(), null);
    }
}
