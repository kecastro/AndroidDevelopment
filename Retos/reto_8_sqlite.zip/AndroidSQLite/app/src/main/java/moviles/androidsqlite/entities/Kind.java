package moviles.androidsqlite.entities;

/**
 * Created by kcastrop on 12/11/17.
 */

public enum Kind {
    Fabrica, Consultoria, Desarollo
}
