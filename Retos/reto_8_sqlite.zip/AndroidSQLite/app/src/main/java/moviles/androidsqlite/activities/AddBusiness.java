package moviles.androidsqlite.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import moviles.androidsqlite.R;
import moviles.androidsqlite.db.BusinessOperations;
import moviles.androidsqlite.entities.Business;
import moviles.androidsqlite.entities.Kind;

/**
 * Created by kcastrop on 13/11/17.
 */

public class AddBusiness extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText name;
    private EditText url;
    private EditText phone;
    private EditText email;
    private EditText products;
    private Spinner kinds;
    private Button create;

    private Business newBusiness;
    private BusinessOperations businessData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_business);

        newBusiness = new Business();

        name = (EditText)findViewById(R.id.name);
        url = (EditText)findViewById(R.id.url);
        phone = (EditText)findViewById(R.id.phone);
        email = (EditText)findViewById(R.id.email);
        products = (EditText)findViewById(R.id.products);
        kinds = (Spinner) findViewById(R.id.kinds);
        create = (Button)findViewById(R.id.btn_create);

        kinds.setAdapter(new ArrayAdapter<Kind>(this, android.R.layout.simple_spinner_item, Kind.values()));
        kinds.setOnItemSelectedListener(this);

        businessData = new BusinessOperations(this);
        businessData.open();

        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                newBusiness.setName(name.getText().toString());
                newBusiness.setUrl(url.getText().toString());
                newBusiness.setPhone(phone.getText().toString());
                newBusiness.setEmail(email.getText().toString());
                newBusiness.setProducts(products.getText().toString());
                businessData.addBusiness(newBusiness);

                Intent i = new Intent(AddBusiness.this,MainActivity.class);
                startActivity(i);
            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
        newBusiness.setKind(Kind.valueOf(parent.getItemAtPosition(pos).toString()));
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
