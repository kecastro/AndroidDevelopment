package tictactoe.unal.edu.co.tictactoe;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class AndroidTicTaToeOnlineActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference currentGame;


    private TicTacToeGameOnline mGame;
    private BoardViewOnline mBoardView;
    private TextView mWhoamiTextView;

    String gameId;
    String whoAmI;
    String rival;
    char item;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_android_tic_ta_toe_online);
        Bundle bundle = getIntent().getExtras();
        gameId = bundle.getString("gameid");
        whoAmI = bundle.getString("whoami");
        database = FirebaseDatabase.getInstance();
        currentGame = database.getReference("games/" + gameId);
        mGame = new TicTacToeGameOnline();
        mWhoamiTextView = (TextView) findViewById(R.id.whoami);
        mWhoamiTextView.setText(whoAmI);
        mBoardView = (BoardViewOnline) findViewById(R.id.board);
        mBoardView.setOnTouchListener(mTouchListener);
        mBoardView.setGame(mGame);
        updateGame();
        syncBoard();
    }

    public void updateGame(){
        if(whoAmI.equals("p2")){
            item = 'X';
            rival = "p1";
        }
        else {
            item = 'O';
            rival = "p2";
        }
    }

    public void makeOnlineMove(String player, int pos){
        ArrayList<String> newMove = new ArrayList<>();
        char currentBoard[] = mGame.getBoardState();
        for(char play: currentBoard){
            newMove.add(Character.toString(play));
        }

        DatabaseReference updateMove = database.getReference("games/" + gameId + "/board");
        DatabaseReference updateTurn = database.getReference("games/" + gameId + "/turn");
        updateMove.setValue(newMove);
        updateTurn.setValue(rival);

    }

    public void syncBoard(){
        DatabaseReference currentBoard = database.getReference("games/" + gameId + "/board");
        currentBoard.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                ArrayList<String> b = new ArrayList<>();
                GenericTypeIndicator<ArrayList<String>> t = new GenericTypeIndicator<ArrayList<String>>() {};
                b = dataSnapshot.getValue(t);
                for(int i = 0; i < b.size(); i++){
                    mGame.setMove(b.get(i).charAt(0),i);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("Error Firebase DB", "Failed to read value.", error.toException());
            }
        });

    }

    public void endGame(){
        DatabaseReference updateGame = database.getReference("games/" + gameId + "/state");
        updateGame.setValue("close");
        startActivity(new Intent(getApplicationContext(),IndexActivity.class));
    }


     // Listen for touches on the board
    private View.OnTouchListener mTouchListener = new View.OnTouchListener() {
        public boolean onTouch(View v, MotionEvent event) {

            // Determine which cell was touched
            int col = (int) event.getX() / mBoardView.getBoardCellWidth();
            int row = (int) event.getY() / mBoardView.getBoardCellHeight();
            final int pos = row * 3 + col;

            DatabaseReference updateTurn = database.getReference("games/" + gameId + "/turn");
            updateTurn.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    String turn = dataSnapshot.getValue(String.class);
                    if(turn.equals(whoAmI)){
                        if (mGame.setMove(item, pos))	{

                            mBoardView.invalidate();
                            makeOnlineMove(Character.toString(item), pos);

                            // If no winner yet, let the computer make a move
                            int winner = mGame.checkForWinner();

                        }
                    }
                }
                @Override
                public void onCancelled(DatabaseError error) {
                    Log.w("Error Firebase DB", "Failed to read value.", error.toException());
                }
            });

            // So we aren't notified of continued events when finger is moved
            return false;
        }
    };


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu_online, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.abandon_game:
                endGame();
                return true;
        }
        return false;

    }

    @Override
    protected void onPause() {
        super.onPause();
        endGame();
    }

    @Override
    protected void onStop() {
        super.onStop();
        endGame();
    }

}
