package tictactoe.unal.edu.co.tictactoe;

/**
 * Created by kevincastro on 8/27/17.
 */

/* TicTacToeGame.java
 * By Frank McCown (Harding University)
 * 
 * This is a tic-tac-toe game that runs in the console window.  The human
 * is X and the computer is O. 
 */

import java.util.Random;

public class TicTacToeGameOnline {

    private char mBoard[] = {OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT,OPEN_SPOT};
    public static final int BOARD_SIZE = 9;

    public static final char HUMAN_PLAYER1 = 'O';
    public static final char HUMAN_PLAYER2 = 'X';
    public static final char OPEN_SPOT = ' ';
    public String turn;
    
    private Random mRand;


    public TicTacToeGameOnline() {

        // Seed the random number generator
        mRand = new Random();

    }

    /** Clear the board of all X's and O's by setting all spots to OPEN_SPOT. */
    public void clearBoard(){

        for(int i = 0; i < mBoard.length; i++){
            mBoard[i] = OPEN_SPOT;
        }

    }

    /** Set the given player at the given location on the game board.
     * * * * */
    public boolean setMove(char player, int location){

        if(player == HUMAN_PLAYER1){
            mBoard[location] = HUMAN_PLAYER1;
            return true;
        }else if(player == HUMAN_PLAYER2){
            mBoard[location] = HUMAN_PLAYER2;
            return true;
        }

        return false;
    }

    public String getTurn() {
        return turn;
    }

    public void setTurn(String turn) {
        this.turn = turn;
    }

    // Check for a winner.  Return
    //  0 if no winner or tie yet
    //  1 if it's a tie
    //  2 if X won
    //  3 if O won
    public int checkForWinner() {

        // Check horizontal wins
        for (int i = 0; i <= 6; i += 3)	{
            if (mBoard[i] == HUMAN_PLAYER1 &&
                    mBoard[i+1] == HUMAN_PLAYER1 &&
                    mBoard[i+2]== HUMAN_PLAYER1)
                return 2;
            if (mBoard[i] == HUMAN_PLAYER2 &&
                    mBoard[i+1]== HUMAN_PLAYER2 &&
                    mBoard[i+2] == HUMAN_PLAYER2)
                return 3;
        }

        // Check vertical wins
        for (int i = 0; i <= 2; i++) {
            if (mBoard[i] == HUMAN_PLAYER1 &&
                    mBoard[i+3] == HUMAN_PLAYER1 &&
                    mBoard[i+6]== HUMAN_PLAYER1)
                return 2;
            if (mBoard[i] == HUMAN_PLAYER2 &&
                    mBoard[i+3] == HUMAN_PLAYER2 &&
                    mBoard[i+6]== HUMAN_PLAYER2)
                return 3;
        }

        // Check for diagonal wins
        if ((mBoard[0] == HUMAN_PLAYER1 &&
                mBoard[4] == HUMAN_PLAYER1 &&
                mBoard[8] == HUMAN_PLAYER1) ||
                (mBoard[2] == HUMAN_PLAYER1 &&
                        mBoard[4] == HUMAN_PLAYER1 &&
                        mBoard[6] == HUMAN_PLAYER1))
            return 2;
        if ((mBoard[0] == HUMAN_PLAYER2 &&
                mBoard[4] == HUMAN_PLAYER2 &&
                mBoard[8] == HUMAN_PLAYER2) ||
                (mBoard[2] == HUMAN_PLAYER2 &&
                        mBoard[4] == HUMAN_PLAYER2 &&
                        mBoard[6] == HUMAN_PLAYER2))
            return 3;

        // Check for tie
        for (int i = 0; i < BOARD_SIZE; i++) {
            // If we find a number, then no one has won yet
            if (mBoard[i] != HUMAN_PLAYER1 && mBoard[i] != HUMAN_PLAYER2)
                return 0;
        }

        // If we make it through the previous loop, all places are taken, so it's a tie
        return 1;
    }

    public char getBoardOccupant(int i){
        return mBoard[i];
    }

    public char[] getBoardState(){
        return mBoard;
    }

    public void setBoardState(char[] state){
        mBoard = state;
    }

}