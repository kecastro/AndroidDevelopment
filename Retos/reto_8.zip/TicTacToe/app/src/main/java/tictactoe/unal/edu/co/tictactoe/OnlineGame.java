package tictactoe.unal.edu.co.tictactoe;

import java.util.ArrayList;

/**
 * Created by kcastrop on 30/10/17.
 */

public class OnlineGame {

    public String gameId;
    public String p1Id;
    public String p2Id;
    public String p1Name;
    public String p2Name;
    public String turn;
    public String state;
    public ArrayList<String> board;

    public static final int BOARD_SIZE = 9;

    public OnlineGame(){}

    public OnlineGame(String gameId, String p1Id, String p1Name) {
        this.gameId = gameId;

        this.p1Id = p1Id;
        this.p1Name = p1Name;
        this.p2Id = null;

        this.p2Name = null;
        this.turn = "p1";
        this.state = "open";
        this.board = new ArrayList<String>();
        for(int i = 0; i < BOARD_SIZE; i++)
            this.board.add(" ");
    }

    public String getGameId() {
        return gameId;
    }

    public void setGameId(String gameId) {
        this.gameId = gameId;
    }

    public ArrayList<String> getBoard() {
        return board;
    }

    public void setBoard(ArrayList<String> board) {
        this.board = board;
    }

    public String getP1Id() {
        return p1Id;
    }

    public void setP1Id(String p1Id) {
        this.p1Id = p1Id;
    }

    public String getP2Id() {
        return p2Id;
    }

    public void setP2Id(String p2Id) {
        this.p2Id = p2Id;
    }

    public String getP1Name() {
        return p1Name;
    }

    public void setP1Name(String p1Name) {
        this.p1Name = p1Name;
    }

    public String getP2Name() {
        return p2Name;
    }

    public void setP2Name(String p2Name) {
        this.p2Name = p2Name;
    }

    public String getTurn() {
        return turn;
    }

    public void setTurn(String turn) {
        this.turn = turn;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        return this.gameId;
    }
}
