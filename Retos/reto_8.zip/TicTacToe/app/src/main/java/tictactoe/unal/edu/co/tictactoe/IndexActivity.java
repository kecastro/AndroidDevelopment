package tictactoe.unal.edu.co.tictactoe;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Random;

public class IndexActivity extends AppCompatActivity {

    FirebaseDatabase database;
    DatabaseReference onlineGames;

    private ListView gamesList;
    private ArrayList<OnlineGame> games;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_index);
        database = FirebaseDatabase.getInstance();
        onlineGames = database.getReference("games");
        gamesList = (ListView) findViewById(R.id.list_game);

        loadGames();

        gamesList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                OnlineGame game = games.get(i);
                Intent intent = new Intent(getApplicationContext(),AndroidTicTaToeOnlineActivity.class);
                intent.putExtra("gameid", game.getGameId());
                intent.putExtra("whoami", "p2");

                DatabaseReference p2Name = database.getReference("games/" + game.getGameId() + "/p2Name");
                p2Name.setValue("Jugador 2");
                DatabaseReference p2Id = database.getReference("games/" + game.getGameId() + "/p2Id");
                p2Id.setValue(getRandId());

                startActivity(intent);
            }
        });

    }

    private void loadGames(){
        final DatabaseReference allGames  = database.getReference().child("games");
        allGames.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                games = new ArrayList<OnlineGame>();
                for(DataSnapshot gamesSnapshot: dataSnapshot.getChildren()){
                    OnlineGame g = gamesSnapshot.getValue(OnlineGame.class);
                    if(g.state.equals("open"))
                        games.add(g);
                }

                ArrayAdapter<OnlineGame> adapter
                    = new ArrayAdapter<OnlineGame>
                        (IndexActivity.this, android.R.layout.simple_list_item_1, games);
                gamesList.setAdapter(adapter);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                Log.w("Error Firebase DB", "Failed to read value.", error.toException());
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options_menu_main, menu);
        return true;

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.new_local_game:
                startActivity(new Intent(getApplicationContext(), AndroidTicTacToeActivity.class));
                return true;
            case R.id.new_online_game:
                String gameId = generateOnlineGame();
                Intent intent = new Intent(getApplicationContext(), AndroidTicTaToeOnlineActivity.class);
                intent.putExtra("gameid", gameId);
                intent.putExtra("whoami", "p1");
                startActivity(intent);
                return true;
        }
        return false;

    }

    public String generateOnlineGame(){
        OnlineGame game = new OnlineGame(getRandId(), getRandId(), "Jugador 1");
        DatabaseReference newgame = database.getReference("games/" + game.getGameId());
        newgame.setValue(game);

        return game.getGameId();
    }


    protected String getRandId() {
        String OPTIONS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder s = new StringBuilder();
        Random rnd = new Random();
        while (s.length() < 10) { // length of the random string.
            int index = (int) (rnd.nextFloat() * OPTIONS.length());
            s.append(OPTIONS.charAt(index));
        }
        String randId = s.toString();
        return randId;

    }


}
