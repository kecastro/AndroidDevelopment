package tictactoe.unal.edu.co.tictactoe;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by kcastrop on 18/09/17.
 */

public class BoardViewOnline extends View{

    // Width of the board grid lines
    public static final int GRID_WIDTH = 6;
    private Bitmap mHuman1Bitmap;
    private Bitmap mHuman2Bitmap;

    private Paint mPaint;

    private TicTacToeGameOnline mGame;

    public void setGame(TicTacToeGameOnline game) {
        mGame = game;
    }

    public int getBoardCellWidth() {
        return getWidth() / 3;
    }

    public int getBoardCellHeight() {
        return getHeight() / 3;
    }

    public BoardViewOnline(Context context) {
        super(context);
        initialize();
    }

    public BoardViewOnline(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        initialize();
    }

    public BoardViewOnline(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize();
    }

    public void initialize() {
        mHuman1Bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.circle);
        mHuman2Bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.cross);
        mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Determine the width and height of the View
        int boardWidth = getWidth();
        int boardHeight = getHeight();

        // Make thick, light gray lines
        mPaint.setColor(Color.LTGRAY);
        mPaint.setStrokeWidth(GRID_WIDTH);

        // Draw the two vertical board lines
        int cellWidth = boardWidth / 3;
        canvas.drawLine(cellWidth, 0, cellWidth, boardHeight, mPaint);
        canvas.drawLine(cellWidth * 2, 0, cellWidth * 2, boardHeight, mPaint);

        // Draw the two horizontal board lines
        int cellHeight = cellWidth;
        canvas.drawLine(0, cellHeight, boardWidth, cellHeight, mPaint);
        canvas.drawLine(0, cellHeight * 2, boardWidth, cellHeight * 2, mPaint);

        // Draw all the X and O images
        for (int i = 0; i < TicTacToeGameOnline.BOARD_SIZE; i++) {
            int col = i % 3;
            int row = i / 3;

            // Define the boundaries of a destination rectangle for the image
            int left = col * cellWidth;
            int top = row * cellHeight;
            int right = left + cellWidth;
            int bottom = top + cellHeight;

            if (mGame != null && mGame.getBoardOccupant(i) == TicTacToeGameOnline.HUMAN_PLAYER1) {
                canvas.drawBitmap(mHuman1Bitmap,
                        null,  // src
                        new Rect(left, top, right, bottom),  // dest
                        null);
            }
            else if (mGame != null && mGame.getBoardOccupant(i) == TicTacToeGameOnline.HUMAN_PLAYER2) {
                canvas.drawBitmap(mHuman2Bitmap,
                        null,  // src
                        new Rect(left, top, right, bottom),  // dest
                        null);
            }
        }

    }
}
